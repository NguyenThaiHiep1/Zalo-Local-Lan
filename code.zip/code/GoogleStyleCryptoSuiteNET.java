import java.awt.*;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.KeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.DefaultCaret;

/**
 * MILITARY CRYPTO SUITE - PHIÊN BẢN TỔNG HỢP FINAL
 * ------------------------------------------------
 * - Tab 1 & 2: Giữ nguyên logic gốc của bạn (Đã fix lỗi RSA).
 * - Tab 3: Nâng cấp Gọi điện (Có chuông) & Gửi file (TCP ổn định).
 */
public class GoogleStyleCryptoSuiteNET extends JFrame {

    // =========================================================================
    // 1. CẤU HÌNH GIAO DIỆN & MÀU SẮC
    // =========================================================================
    private static final Color COL_PRIMARY = new Color(13, 110, 253); 
    private static final Color COL_SUCCESS = new Color(25, 135, 84);  
    private static final Color COL_WARNING = new Color(255, 193, 7);  
    private static final Color COL_GRAY    = new Color(108, 117, 125);
    private static final Color COL_BG_LIGHT= new Color(248, 249, 250);

    // =========================================================================
    // 2. CẤU HÌNH CRYPTO
    // =========================================================================
    private static final String ALGO_AES_GCM = "AES/GCM/NoPadding";
    private static final int AES_KEY_SIZE = 256; 
    private static final int GCM_IV_LEN = 12;    
    private static final int GCM_TAG_LEN = 128;  
    private static final int SALT_LEN = 16;      
    private static final String ALGO_KDF = "PBKDF2WithHmacSHA512";
    
    private static final int RSA_KEY_SIZE = 2048;
    private static final int RSA_SIGNATURE_SIZE = 256; 
    private static final int VOICE_BUFFER_SIZE = 1024;

    // Tín hiệu điều khiển cuộc gọi
    private static final String CMD_CALL_REQ = "!!!CMD_CALL_REQ!!!"; // Yêu cầu gọi
    private static final String CMD_CALL_ACC = "!!!CMD_CALL_ACC!!!"; // Đồng ý
    private static final String CMD_CALL_DENY = "!!!CMD_CALL_DENY!!!"; // Từ chối

    private KeyPair rsaKeyPair; 
    private SecretKey networkSessionKey; 

    // UI Variables
    private JTextArea msgInput, msgOutput, chatHistory;
    private JPasswordField msgPass, filePass, txtNetPass;
    private JTextField srcField, dstField;
    private JProgressBar progressBar;
    private JLabel statusLabel;
    
    // Network UI
    private JTextField txtIp, txtPort, txtChatInput, txtNickName;
    private JComboBox<String> cmbProtocol;
    private JLabel lblNetStatus;
    private JButton btnVoice; // Nút gọi
    
    // Network Logic
    private DatagramSocket udpSocket;       
    private ServerSocket fileServerSocket;  
    private JProgressBar netProgressBar; // Thanh tiến trình gửi file

    private volatile boolean isServerRunning = false;
    private volatile boolean isCalling = false; 
    
    private Thread audioSendThread, audioRecvThread;

    // =========================================================================
    // 3. KHỞI TẠO (CONSTRUCTOR)
    // =========================================================================
    public GoogleStyleCryptoSuiteNET() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {}

        setTitle("Military Crypto Suite - Secure LAN Comms");
        setSize(1150, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initCryptoSystem(); // Khởi tạo RSA (Đã fix lỗi lưu key)

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        
        tabbedPane.addTab("MÃ HÓA VĂN BẢN", createTextPanel());
        tabbedPane.addTab("KÉT SẮT FILE", createFilePanel());
        tabbedPane.addTab("LIÊN LẠC & GỬI FILE", createNetworkPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    // [QUAN TRỌNG] FIX LỖI RSA: Lưu key ra file để không bị mất khi tắt App
    private void initCryptoSystem() {
        File keyFile = new File("internal_rsa.key");
        // 1. Cố gắng load key cũ
        if (keyFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(keyFile))) {
                rsaKeyPair = (KeyPair) ois.readObject();
                return; // Load thành công
            } catch (Exception e) { System.out.println("Key lỗi, tạo mới..."); }
        }

        // 2. Nếu chưa có thì tạo mới và lưu lại
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(RSA_KEY_SIZE);
            rsaKeyPair = keyGen.generateKeyPair();
            
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(keyFile))) {
                oos.writeObject(rsaKeyPair);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi khởi tạo RSA: " + e.getMessage());
        }
    }

    private SecretKey getAESKey(char[] password, byte[] salt) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGO_KDF);
        KeySpec spec = new PBEKeySpec(password, salt, 65536, AES_KEY_SIZE);
        return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
    }

    // =========================================================================
    // 4. GIAO DIỆN & LOGIC TAB 1 (GIỮ NGUYÊN TỪ FILE GỐC)
    // =========================================================================
    private JPanel createTextPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));
        panel.setBorder(new EmptyBorder(15, 15, 15, 15)); panel.setBackground(Color.WHITE);
        
        // Left Panel
        JPanel left = new JPanel(new BorderLayout(5, 10)); left.setBackground(Color.WHITE);
        left.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        JPanel lHead = new JPanel(new BorderLayout()); lHead.setBackground(Color.WHITE);
        lHead.add(new JLabel("Văn bản gốc"), BorderLayout.WEST);
        
        JPanel lBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0)); lBtns.setBackground(Color.WHITE);
        JButton btnPaste = createSimpleButton("Dán", COL_PRIMARY); 
        JButton btnClear = createSimpleButton("Xóa", COL_GRAY);
        lBtns.add(btnPaste); lBtns.add(btnClear); lHead.add(lBtns, BorderLayout.EAST);

        msgInput = new JTextArea(); msgInput.setLineWrap(true);
        msgInput.setFont(new Font("Monospaced", Font.PLAIN, 14));

        JPanel lFoot = new JPanel(new BorderLayout(5, 10)); lFoot.setBackground(Color.WHITE);
        JPanel keyP = new JPanel(new BorderLayout(5,0)); keyP.setBackground(Color.WHITE);
        keyP.setBorder(BorderFactory.createTitledBorder("Khóa bí mật"));
        msgPass = new JPasswordField();
        JButton btnGenKey = createColoredButton("Tạo Key", COL_WARNING); btnGenKey.setForeground(Color.BLACK);
        btnGenKey.addActionListener(e -> {
            String info = "Độ dài: " + msgInput.getText().length() + " ký tự";
            generateAndExportKey(msgPass, "TAB 1 - VĂN BẢN", info);
        });
        keyP.add(msgPass, BorderLayout.CENTER); keyP.add(btnGenKey, BorderLayout.EAST);

        JPanel actPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        JButton btnEnc = createColoredButton("⛿ MÃ HÓA", COL_PRIMARY); 
        JButton btnDec = createColoredButton("🔓 GIẢI MÃ", COL_SUCCESS);
        btnEnc.setPreferredSize(new Dimension(0, 45)); actPanel.add(btnEnc); actPanel.add(btnDec);
        
        lFoot.add(keyP, BorderLayout.NORTH); lFoot.add(actPanel, BorderLayout.CENTER);
        left.add(lHead, BorderLayout.NORTH); left.add(new JScrollPane(msgInput), BorderLayout.CENTER); left.add(lFoot, BorderLayout.SOUTH);

        // Right Panel
        JPanel right = new JPanel(new BorderLayout(5, 10)); right.setBackground(COL_BG_LIGHT);
        right.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        JPanel rHead = new JPanel(new BorderLayout()); rHead.setBackground(COL_BG_LIGHT);
        rHead.add(new JLabel("Kết quả"), BorderLayout.WEST);
        JButton btnCopy = createSimpleButton("Sao chép", COL_PRIMARY); rHead.add(btnCopy, BorderLayout.EAST);
        msgOutput = new JTextArea(); msgOutput.setLineWrap(true); msgOutput.setEditable(false);
        right.add(rHead, BorderLayout.NORTH); right.add(new JScrollPane(msgOutput), BorderLayout.CENTER);

        // Events
        btnPaste.addActionListener(e -> msgInput.paste()); btnClear.addActionListener(e -> msgInput.setText(""));
        btnCopy.addActionListener(e -> { msgOutput.selectAll(); msgOutput.copy(); });
        btnEnc.addActionListener(e -> handleMsgCrypto(true)); 
        btnDec.addActionListener(e -> handleMsgCrypto(false));

        panel.add(left); panel.add(right);
        return panel;
    }

    // Logic Mã hóa văn bản (Giữ nguyên)
    private void handleMsgCrypto(boolean encrypt) {
        try {
            String txt = msgInput.getText(); 
            char[] pwd = msgPass.getPassword();
            if (pwd.length == 0) return;
            
            if (encrypt) {
                byte[] salt = new byte[SALT_LEN];
                byte[] iv = new byte[GCM_IV_LEN];
                SecureRandom r = new SecureRandom();
                r.nextBytes(salt); r.nextBytes(iv);
                
                SecretKey key = getAESKey(pwd, salt);
                Cipher c = Cipher.getInstance(ALGO_AES_GCM);
                c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_LEN, iv));
                
                byte[] encrypted = c.doFinal(txt.getBytes(StandardCharsets.UTF_8));
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bos.write(salt); bos.write(iv); bos.write(encrypted);
                msgOutput.setText(Base64.getEncoder().encodeToString(bos.toByteArray()));
            } else {
                byte[] decoded = Base64.getDecoder().decode(txt);
                ByteBuffer bb = ByteBuffer.wrap(decoded);
                byte[] salt = new byte[SALT_LEN]; bb.get(salt);
                byte[] iv = new byte[GCM_IV_LEN]; bb.get(iv);
                byte[] cipherText = new byte[bb.remaining()]; bb.get(cipherText);
                
                SecretKey key = getAESKey(pwd, salt);
                Cipher c = Cipher.getInstance(ALGO_AES_GCM);
                c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_LEN, iv));
                msgOutput.setText(new String(c.doFinal(cipherText), StandardCharsets.UTF_8));
            }
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    // =========================================================================
    // 5. GIAO DIỆN & LOGIC TAB 2 (GIỮ NGUYÊN TỪ FILE GỐC)
    // =========================================================================
    private JPanel createFilePanel() {
        JPanel wrapper = new JPanel(new GridBagLayout()); wrapper.setBackground(Color.WHITE);
        JPanel card = new JPanel(new GridBagLayout()); card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), BorderFactory.createEmptyBorder(30, 40, 30, 40)));
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(10, 10, 10, 10); g.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Cấu hình File"); 
        title.setFont(new Font("Segoe UI", Font.BOLD, 16)); title.setHorizontalAlignment(SwingConstants.CENTER);
        g.gridwidth = 3; g.gridx = 0; g.gridy = 0; card.add(title, g);

        srcField = addFileRow(card, g, 1, "File Nguồn:", "Chọn File", false);
        dstField = addFileRow(card, g, 2, "Lưu Tại:", "Chọn Nơi Lưu", true);
        
        g.gridy = 3; g.gridx = 0; g.gridwidth = 1; card.add(new JLabel("Mật Khẩu:"), g);
        filePass = new JPasswordField(30); g.gridx = 1; card.add(filePass, g);
        JButton btnKey = createColoredButton("Sinh Key", COL_WARNING); btnKey.setForeground(Color.BLACK);
        // Sửa trong createFilePanel()
        btnKey.addActionListener(e -> {
            String fileName = srcField.getText();
            if(fileName.isEmpty()) fileName = "[Chưa chọn file]";
            // Chỉ lấy tên file cho ngắn gọn, nếu muốn full đường dẫn thì để nguyên fileName
            String info = "File: " + new File(fileName).getName(); 
            generateAndExportKey(filePass, "TAB 2 - KÉT SẮT FILE", info);
        });
        g.gridx = 2; card.add(btnKey, g);

        JPanel pBtn = new JPanel(new GridLayout(1, 2, 20, 0)); pBtn.setBackground(Color.WHITE);
        JButton btnE = createColoredButton("MÃ HÓA FILE", COL_PRIMARY); 
        JButton btnD = createColoredButton("GIẢI MÃ FILE", COL_SUCCESS);
        btnE.setPreferredSize(new Dimension(0, 50)); pBtn.add(btnE); pBtn.add(btnD);
        g.gridy = 4; g.gridx = 0; g.gridwidth = 3; card.add(pBtn, g);

        statusLabel = new JLabel("Sẵn sàng."); statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        g.gridy = 5; card.add(statusLabel, g);
        progressBar = new JProgressBar(); g.gridy = 6; card.add(progressBar, g);

        wrapper.add(card);
        btnE.addActionListener(e -> processFileLogic(true)); 
        btnD.addActionListener(e -> processFileLogic(false));
        return wrapper;
    }

    private JTextField addFileRow(JPanel p, GridBagConstraints g, int row, String lbl, String btnTxt, boolean save) {
        g.gridy = row; g.gridx = 0; g.gridwidth = 1; p.add(new JLabel(lbl), g);
        JTextField txt = new JTextField(30); g.gridx = 1; g.weightx = 1.0; p.add(txt, g);
        JButton btn = new JButton(btnTxt); btn.setBackground(Color.WHITE);
        btn.addActionListener(e -> chooseFile(txt, save)); g.gridx = 2; g.weightx = 0; p.add(btn, g);
        return txt;
    }

    // Logic xử lý File (Giữ nguyên từ file gốc)
    private void processFileLogic(boolean isEncrypt) {
        String pass = new String(filePass.getPassword());
        if (pass.isEmpty()) { JOptionPane.showMessageDialog(this, "Vui lòng nhập mật khẩu!"); return; }
        File s = new File(srcField.getText()); 
        File d = new File(dstField.getText());

        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                progressBar.setIndeterminate(true);
                if (isEncrypt) { 
                    statusLabel.setText("Đang mã hóa GCM & Ký RSA..."); 
                    performEncryption(s, d, pass); 
                } else { 
                    statusLabel.setText("Đang kiểm tra & Giải mã..."); 
                    performDecryption(s, d, pass); 
                }
                return null;
            }
            @Override protected void done() {
                progressBar.setIndeterminate(false); statusLabel.setText("Hoàn thành.");
                try { get(); JOptionPane.showMessageDialog(null, "Thành công!"); } 
                catch (Exception e) { statusLabel.setText("Lỗi!"); JOptionPane.showMessageDialog(null, "Lỗi: " + e.getCause().getMessage()); }
            }
        }.execute();
    }

    private void performEncryption(File inputFile, File outputFile, String password) throws Exception {
        byte[] salt = new byte[SALT_LEN]; byte[] iv = new byte[GCM_IV_LEN];
        SecureRandom rng = new SecureRandom(); rng.nextBytes(salt); rng.nextBytes(iv);

        SecretKey aesKey = getAESKey(password.toCharArray(), salt);
        Cipher cipher = Cipher.getInstance(ALGO_AES_GCM);
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, new GCMParameterSpec(GCM_TAG_LEN, iv));
        MessageDigest sha3 = MessageDigest.getInstance("SHA3-512");
        
        try (FileInputStream fis = new FileInputStream(inputFile); FileOutputStream fos = new FileOutputStream(outputFile)) {
            fos.write(salt); fos.write(iv);
            try (CipherOutputStream cos = new CipherOutputStream(fos, cipher)) {
                byte[] buffer = new byte[8192]; int bytesRead;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    sha3.update(buffer, 0, bytesRead); cos.write(buffer, 0, bytesRead);
                }
            } 
            Signature rsaSign = Signature.getInstance("SHA512withRSA");
            rsaSign.initSign(rsaKeyPair.getPrivate());
            rsaSign.update(sha3.digest());
            try (FileOutputStream fosAppend = new FileOutputStream(outputFile, true)) { fosAppend.write(rsaSign.sign()); }
        }
    }

    private void performDecryption(File inputFile, File outputFile, String password) throws Exception {
        long fileLen = inputFile.length();
        if (fileLen < (SALT_LEN + GCM_IV_LEN + 16 + RSA_SIGNATURE_SIZE)) throw new IOException("File lỗi!");
        
        try (RandomAccessFile raf = new RandomAccessFile(inputFile, "r")) {
            byte[] salt = new byte[SALT_LEN]; raf.readFully(salt); 
            byte[] iv = new byte[GCM_IV_LEN]; raf.readFully(iv);
            byte[] signature = new byte[RSA_SIGNATURE_SIZE];
            raf.seek(fileLen - RSA_SIGNATURE_SIZE); raf.readFully(signature);
            
            SecretKey aesKey = getAESKey(password.toCharArray(), salt);
            Cipher cipher = Cipher.getInstance(ALGO_AES_GCM);
            cipher.init(Cipher.DECRYPT_MODE, aesKey, new GCMParameterSpec(GCM_TAG_LEN, iv));
            
            MessageDigest sha3 = MessageDigest.getInstance("SHA3-512");
            long contentStart = SALT_LEN + GCM_IV_LEN;
            long contentLen = fileLen - contentStart - RSA_SIGNATURE_SIZE;
            
            raf.seek(contentStart);
            try (FileInputStream fis = new FileInputStream(inputFile); FileOutputStream fos = new FileOutputStream(outputFile)) {
                 fis.skip(contentStart);
                 InputStream lim = new FilterInputStream(fis) {
                     long rem = contentLen;
                     public int read() throws IOException { return (rem-- > 0) ? super.read() : -1; }
                     public int read(byte[] b, int o, int l) throws IOException {
                         if (rem <= 0) return -1;
                         int r = super.read(b, o, (int)Math.min(l, rem)); if (r > 0) rem -= r; return r;
                     }
                 };
                 CipherInputStream cis = new CipherInputStream(lim, cipher);
                 byte[] dBuf = new byte[8192]; int b;
                 while ((b = cis.read(dBuf)) != -1) { fos.write(dBuf, 0, b); sha3.update(dBuf, 0, b); }
            } 
            Signature rsaVerify = Signature.getInstance("SHA512withRSA");
            rsaVerify.initVerify(rsaKeyPair.getPublic());
            rsaVerify.update(sha3.digest());
            if (!rsaVerify.verify(signature)) { outputFile.delete(); throw new IOException("Chữ ký RSA không khớp!"); }
        }
    }

    // =========================================================================
    // 6. GIAO DIỆN & LOGIC TAB 3 (MẠNG - ĐÃ CẬP NHẬT TÍNH NĂNG MỚI)
    // =========================================================================
    private JPanel createNetworkPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel sidebar = new JPanel(); sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(280, 0)); sidebar.setBorder(new EmptyBorder(15, 15, 15, 15));
        sidebar.setBackground(new Color(252, 252, 252));

        JLabel t = new JLabel("Cài đặt mạng"); t.setFont(new Font("Segoe UI", Font.BOLD, 18)); 
        t.setAlignmentX(0.5f); sidebar.add(t); sidebar.add(Box.createVerticalStrut(20));

        addNetField(sidebar, "Tên hiển thị:", txtNickName = new JTextField("Operator"));
        addNetField(sidebar, "IP Đối phương:", txtIp = new JTextField("127.0.0.1"));
        addNetField(sidebar, "Cổng Chính (Port):", txtPort = new JTextField("8888"));

        JPanel keyP = new JPanel(new BorderLayout(5,0)); keyP.setBackground(new Color(252, 252, 252));
        keyP.setMaximumSize(new Dimension(300, 50)); keyP.setAlignmentX(0.0f);
        txtNetPass = new JPasswordField();
        JButton btnK = createColoredButton("Lưu Key", COL_WARNING); btnK.setForeground(Color.BLACK); btnK.setPreferredSize(new Dimension(80,30));
        btnK.addActionListener(e -> generateAndExportKey(txtNetPass, "Mạng", "IP: " + txtIp.getText()));
        keyP.add(new JLabel("Khóa kênh (Bắt buộc):"), BorderLayout.NORTH); keyP.add(txtNetPass, BorderLayout.CENTER); keyP.add(btnK, BorderLayout.EAST);
        sidebar.add(keyP); sidebar.add(Box.createVerticalStrut(20));

        JButton btnHost = createColoredButton("KÍCH HOẠT (GO ONLINE)", COL_PRIMARY);
        JButton btnStop = createColoredButton("NGẮT KẾT NỐI", COL_GRAY);
        btnHost.setMaximumSize(new Dimension(300, 40)); btnStop.setMaximumSize(new Dimension(300, 40));
        
        sidebar.add(btnHost); sidebar.add(Box.createVerticalStrut(10));
        sidebar.add(btnStop); sidebar.add(Box.createVerticalStrut(20));
        
        lblNetStatus = new JLabel("OFFLINE"); lblNetStatus.setForeground(Color.RED); lblNetStatus.setAlignmentX(0.5f);
        sidebar.add(lblNetStatus);

        // Chat & Call Area
        JPanel chatP = new JPanel(new BorderLayout(10, 10));
        chatP.setBorder(new EmptyBorder(15, 15, 15, 15)); chatP.setBackground(Color.WHITE);
        JPanel chatHead = new JPanel(new BorderLayout()); chatHead.setBackground(Color.WHITE);
        chatHead.add(new JLabel("Kênh liên lạc bảo mật (GCM)", JLabel.LEFT), BorderLayout.WEST);
        
        JPanel headRight = new JPanel(new FlowLayout(FlowLayout.RIGHT)); headRight.setBackground(Color.WHITE);
        btnVoice = new JButton("📞 GỌI ĐIỆN"); btnVoice.setBackground(new Color(220, 53, 69)); btnVoice.setForeground(Color.WHITE);
        headRight.add(btnVoice); chatHead.add(headRight, BorderLayout.EAST);

        chatHistory = new JTextArea(); chatHistory.setEditable(false);
        DefaultCaret caret = (DefaultCaret)chatHistory.getCaret(); caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        // Footer: Input + File Transfer
        JPanel chatFoot = new JPanel(new BorderLayout(10, 0)); chatFoot.setBackground(Color.WHITE);
        netProgressBar = new JProgressBar(); netProgressBar.setStringPainted(true); netProgressBar.setVisible(false);
        
        JPanel inputPanel = new JPanel(new BorderLayout(5, 0)); inputPanel.setBackground(Color.WHITE);
        JButton btnAttach = new JButton("📎 GỬI FILE"); btnAttach.setBackground(Color.WHITE);
        txtChatInput = new JTextField(); 
        JButton btnSend = createColoredButton("GỬI CHAT", COL_PRIMARY);
        
        inputPanel.add(btnAttach, BorderLayout.WEST); 
        inputPanel.add(txtChatInput, BorderLayout.CENTER); 
        inputPanel.add(btnSend, BorderLayout.EAST);
        
        chatFoot.add(netProgressBar, BorderLayout.NORTH);
        chatFoot.add(inputPanel, BorderLayout.CENTER);

        chatP.add(chatHead, BorderLayout.NORTH); chatP.add(new JScrollPane(chatHistory), BorderLayout.CENTER); chatP.add(chatFoot, BorderLayout.SOUTH);
        panel.add(sidebar, BorderLayout.WEST); panel.add(chatP, BorderLayout.CENTER);

        // --- EVENTS ---
        btnHost.addActionListener(e -> startUDPServer());
        btnStop.addActionListener(e -> stopUDPServer());
        btnSend.addActionListener(e -> sendUDPMessage(null));
        txtChatInput.addActionListener(e -> sendUDPMessage(null));
        
        // [CẬP NHẬT] Sự kiện Gọi điện và Gửi file
        btnVoice.addActionListener(e -> initiateVoiceCall());
        btnAttach.addActionListener(e -> sendFileSecurely());
        
        return panel;
    }

    // --- LOGIC GỌI ĐIỆN MỚI (SIGNALING) ---
    private void initiateVoiceCall() {
        if (!isServerRunning) { JOptionPane.showMessageDialog(this, "Chưa kết nối mạng!"); return; }
        if (isCalling) { // Đang gọi -> Tắt
            stopVoiceCall(); sendUDPMessage(CMD_CALL_DENY);
        } else { // Chưa gọi -> Gửi yêu cầu
            chatHistory.append(">> Đang gọi cho " + txtIp.getText() + "...\n");
            sendUDPMessage(CMD_CALL_REQ);
        }
    }

    private void handleIncomingSignal(String signal, String senderIP) {
        SwingUtilities.invokeLater(() -> {
            switch (signal) {
                case CMD_CALL_REQ:
                    int choice = JOptionPane.showConfirmDialog(this, "Cuộc gọi từ " + senderIP + "! Nghe không?", "GỌI ĐẾN", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) {
                        sendUDPMessage(CMD_CALL_ACC); startVoiceThreads(); chatHistory.append(">> Đã nhận cuộc gọi.\n");
                    } else {
                        sendUDPMessage(CMD_CALL_DENY); chatHistory.append(">> Đã từ chối.\n");
                    }
                    break;
                case CMD_CALL_ACC:
                    chatHistory.append(">> Đối phương đã nghe máy.\n"); startVoiceThreads(); break;
                case CMD_CALL_DENY:
                    chatHistory.append(">> Cuộc gọi bị từ chối/kết thúc.\n"); stopVoiceCall(); break;
            }
        });
    }

    private void stopVoiceCall() {
        isCalling = false; btnVoice.setText("📞 GỌI ĐIỆN"); btnVoice.setBackground(new Color(220, 53, 69));
    }

    private void startVoiceThreads() {
        if(isCalling) return; isCalling = true;
        btnVoice.setText("📴 DỪNG GỌI"); btnVoice.setBackground(Color.GRAY);
        
        audioSendThread = new Thread(() -> {
            try {
                AudioFormat format = new AudioFormat(8000.0f, 16, 1, true, true);
                TargetDataLine microphone = AudioSystem.getTargetDataLine(format);
                microphone.open(format); microphone.start();
                byte[] buffer = new byte[VOICE_BUFFER_SIZE];
                InetAddress ip = InetAddress.getByName(txtIp.getText());
                int port = Integer.parseInt(txtPort.getText()) + 1;
                while (isCalling) {
                    int bytesRead = microphone.read(buffer, 0, buffer.length);
                    if (bytesRead > 0) {
                        byte[] enc = encryptPacketGCM(Arrays.copyOf(buffer, bytesRead), networkSessionKey);
                        udpSocket.send(new DatagramPacket(enc, enc.length, ip, port));
                    }
                }
                microphone.close();
            } catch (Exception e) {}
        });

        audioRecvThread = new Thread(() -> {
            try (DatagramSocket vs = new DatagramSocket(Integer.parseInt(txtPort.getText()) + 1)) {
                byte[] buf = new byte[2048];
                AudioFormat format = new AudioFormat(8000.0f, 16, 1, true, true);
                SourceDataLine speakers = AudioSystem.getSourceDataLine(format);
                speakers.open(format); speakers.start();
                while (isCalling) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length); vs.receive(p);
                    byte[] dec = decryptPacketGCM(Arrays.copyOf(p.getData(), p.getLength()), networkSessionKey);
                    speakers.write(dec, 0, dec.length);
                }
                speakers.close();
            } catch (Exception e) {}
        });
        audioSendThread.start(); audioRecvThread.start();
    }

    // --- LOGIC GỬI FILE TCP MỚI ---
    private void sendFileSecurely() {
        if (!isServerRunning) { JOptionPane.showMessageDialog(this, "Chưa bấm KÍCH HOẠT!"); return; }
        JFileChooser c = new JFileChooser();
        if (c.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = c.getSelectedFile();
            new Thread(() -> {
                try {
                    SwingUtilities.invokeLater(() -> {
                        netProgressBar.setVisible(true); netProgressBar.setValue(0); netProgressBar.setString("Đang gửi...");
                    });
                    try (Socket s = new Socket(txtIp.getText(), Integer.parseInt(txtPort.getText()) + 2);
                         DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                         FileInputStream fis = new FileInputStream(f)) {
                        dos.writeUTF(f.getName()); dos.writeLong(f.length()); dos.flush();
                        byte[] buf = new byte[4096]; long sent = 0; int r;
                        while ((r = fis.read(buf)) != -1) {
                            byte[] enc = encryptPacketGCM(Arrays.copyOf(buf, r), networkSessionKey);
                            dos.writeInt(enc.length); dos.write(enc); dos.flush();
                            sent += r; int pct = (int)((sent*100)/f.length());
                            SwingUtilities.invokeLater(() -> netProgressBar.setValue(pct));
                        }
                    }
                    SwingUtilities.invokeLater(() -> { netProgressBar.setString("Xong!"); chatHistory.append(">> Đã gửi file.\n"); });
                } catch (Exception e) { SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, "Lỗi gửi: " + e.getMessage())); }
            }).start();
        }
    }

    private void startFileReceiver(int port) {
        try {
            fileServerSocket = new ServerSocket(port);
            while (isServerRunning) {
                Socket s = fileServerSocket.accept();
                new Thread(() -> {
                    try (DataInputStream dis = new DataInputStream(s.getInputStream())) {
                        String name = dis.readUTF(); long size = dis.readLong();
                        SwingUtilities.invokeLater(() -> {
                            chatHistory.append(">> Nhận file: " + name + "...\n");
                            netProgressBar.setVisible(true); netProgressBar.setString("Đang nhận...");
                        });
                        File dir = new File("Received_Files"); if(!dir.exists()) dir.mkdir();
                        File out = new File(dir, "Recv_" + System.currentTimeMillis() + "_" + name);
                        try (FileOutputStream fos = new FileOutputStream(out)) {
                            long recv = 0;
                            while (recv < size) {
                                int len = dis.readInt(); byte[] enc = new byte[len]; dis.readFully(enc);
                                byte[] dec = decryptPacketGCM(enc, networkSessionKey);
                                fos.write(dec); recv += dec.length;
                                int pct = (int)((recv*100)/size);
                                SwingUtilities.invokeLater(() -> netProgressBar.setValue(pct));
                            }
                        }
                        SwingUtilities.invokeLater(() -> { netProgressBar.setVisible(false); chatHistory.append(">> Lưu tại: " + out.getAbsolutePath() + "\n"); });
                    } catch (Exception e) {}
                }).start();
            }
        } catch (IOException e) {}
    }

    // --- CÁC HÀM HỖ TRỢ CHUNG ---
    private void startUDPServer() {
        if (isServerRunning) return;
        try {
            String pass = new String(txtNetPass.getPassword());
            if(pass.isEmpty()) { JOptionPane.showMessageDialog(this, "Thiếu khóa kênh!"); return; }
            networkSessionKey = getAESKey(pass.toCharArray(), "NetSalt".getBytes());
            int port = Integer.parseInt(txtPort.getText());
            udpSocket = new DatagramSocket(port); isServerRunning = true;
            lblNetStatus.setText("ONLINE"); lblNetStatus.setForeground(COL_SUCCESS);
            
            new Thread(() -> { // Thread chat
                byte[] buf = new byte[4096];
                while(isServerRunning) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length); udpSocket.receive(p);
                        byte[] dec = decryptPacketGCM(Arrays.copyOf(p.getData(), p.getLength()), networkSessionKey);
                        String s = new String(dec, StandardCharsets.UTF_8);
                        if(s.equals(CMD_CALL_REQ) || s.equals(CMD_CALL_ACC) || s.equals(CMD_CALL_DENY)) handleIncomingSignal(s, p.getAddress().getHostAddress());
                        else SwingUtilities.invokeLater(() -> chatHistory.append("["+p.getAddress().getHostAddress()+"]: "+s+"\n"));
                    } catch(Exception e) {}
                }
            }).start();
            new Thread(() -> startFileReceiver(port+2)).start(); // Thread file
        } catch(Exception e) { JOptionPane.showMessageDialog(this, "Lỗi Server: " + e.getMessage()); }
    }

    private void stopUDPServer() {
        isServerRunning = false; stopVoiceCall();
        if(udpSocket != null) udpSocket.close();
        if(fileServerSocket != null) try{fileServerSocket.close();}catch(Exception e){}
        lblNetStatus.setText("OFFLINE"); lblNetStatus.setForeground(Color.RED);
    }

    private void sendUDPMessage(String override) {
        if(udpSocket == null) return;
        try {
            String msg = (override!=null) ? override : "["+txtNickName.getText()+"]: "+txtChatInput.getText();
            byte[] raw = msg.getBytes(StandardCharsets.UTF_8);
            byte[] enc = encryptPacketGCM(raw, networkSessionKey);
            udpSocket.send(new DatagramPacket(enc, enc.length, InetAddress.getByName(txtIp.getText()), Integer.parseInt(txtPort.getText())));
            if(override==null) { chatHistory.append("Tôi: "+txtChatInput.getText()+"\n"); txtChatInput.setText(""); }
        } catch(Exception e) { JOptionPane.showMessageDialog(this, "Lỗi gửi: " + e.getMessage()); }
    }

    private byte[] encryptPacketGCM(byte[] data, SecretKey key) throws Exception {
        byte[] iv = new byte[GCM_IV_LEN]; new SecureRandom().nextBytes(iv);
        Cipher c = Cipher.getInstance(ALGO_AES_GCM); c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_LEN, iv));
        byte[] ct = c.doFinal(data); ByteBuffer bb = ByteBuffer.allocate(iv.length + ct.length); bb.put(iv); bb.put(ct); return bb.array();
    }
    private byte[] decryptPacketGCM(byte[] packet, SecretKey key) throws Exception {
        ByteBuffer bb = ByteBuffer.wrap(packet); byte[] iv = new byte[GCM_IV_LEN]; bb.get(iv);
        byte[] ct = new byte[bb.remaining()]; bb.get(ct);
        Cipher c = Cipher.getInstance(ALGO_AES_GCM); c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_LEN, iv)); return c.doFinal(ct);
    }
    // private void generateAndExportKey(JPasswordField f, String t, String d) {
    //     byte[] r = new byte[16]; new SecureRandom().nextBytes(r); f.setText(Base64.getEncoder().encodeToString(r).substring(0,16));
    //     JOptionPane.showMessageDialog(this, "Đã sinh Key mới!");
    // }

    private void generateAndExportKey(JPasswordField field, String tabName, String details) {
        // 1. Sinh Key ngẫu nhiên (Logic cũ)
        byte[] r = new byte[16];
        new SecureRandom().nextBytes(r);
        String key = Base64.getEncoder().encodeToString(r).substring(0, 16);
        field.setText(key);

        // 2. Lấy thời gian hiện tại
        String timeLog = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy"));

        // 3. Soạn nội dung Log theo định dạng "quân sự" gọn gàng
        StringBuilder sb = new StringBuilder();
        sb.append("+--------------------------------------------------+\n");
        sb.append(String.format("| THỜI GIAN : %-32s |\n", timeLog));
        sb.append(String.format("| CHỨC NĂNG : %-32s |\n", tabName.toUpperCase())); // Tên Tab
        sb.append(String.format("| CHI TIẾT  : %-32s |\n", details)); // Thông tin file/ip/text
        sb.append(String.format("| KEY (MAT) : %-32s |\n", key));
        sb.append("+--------------------------------------------------+\n\n");

        // 4. Ghi nối tiếp vào file History_Keys.txt
        try (FileWriter fw = new FileWriter("History_Keys.txt", true)) {
            fw.write(sb.toString());
            JOptionPane.showMessageDialog(this, 
                "Đã sinh Key và lưu vào hồ sơ 'History_Keys.txt'.\n" +
                "Chức năng: " + tabName);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Lỗi ghi file log: " + e.getMessage());
        }
    }

    private JButton createColoredButton(String t, Color c) {
        JButton b = new JButton(t); b.setBackground(c); b.setForeground(Color.WHITE); b.setFocusPainted(false); b.setFont(new Font("Segoe UI", Font.BOLD, 12)); return b;
    }
    private JButton createSimpleButton(String t, Color c) {
        JButton b = new JButton(t); b.setBackground(c); b.setForeground(c==COL_GRAY?Color.BLACK:Color.WHITE); b.setMargin(new Insets(2,10,2,10)); return b;
    }
    private void addNetField(JPanel p, String l, JComponent c) {
        JPanel t = new JPanel(new BorderLayout()); t.setMaximumSize(new Dimension(300, 50)); t.setAlignmentX(0.0f);
        t.add(new JLabel(l), BorderLayout.NORTH); t.add(c, BorderLayout.CENTER); p.add(t); p.add(Box.createVerticalStrut(10));
    }
    private void chooseFile(JTextField f, boolean s) { JFileChooser c=new JFileChooser(); if((s?c.showSaveDialog(this):c.showOpenDialog(this))==JFileChooser.APPROVE_OPTION) f.setText(c.getSelectedFile().getAbsolutePath()); }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new GoogleStyleCryptoSuiteNET().setVisible(true)); }
}